package codingon.codingonspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingonSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingonSpringBootApplication.class, args);
	}

}
